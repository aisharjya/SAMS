/*
 * common.cpp
 *
 *  Created on: Jan 12, 2016
 *  Author: aisharjya
 */

#include "common.h"

int totalNodes;
int totalEdges;
int **adjGraph;
map<int, vector<int> > adjNodeList;
int parentPopSize=100;
int initPopSize=100;
int solutionLen;
int initSolLen=100;
//int totalSamples=200;
int totalSamples=159;
int maxIterationNo=1000;
int maxRepeatationNo=20;
vector<vector<int> > parentPopulation;
vector<vector<int> > childPopulation;
vector<vector<int> > mergedPopulation;
vector<vector<int> > mutationData;
vector<vector<int> > patientData;
vector<vector<int> > _P0;
vector<vector<int> > _P1;
map<double, int> scoreMap;
vector<int> _bestSol;
vector<int> _prevBestSol;
double logRankScore;
vector<bool> visited;
int componentSize;
int minComponentSize=10;
map<int, double> geneSurvivalTimeMap;
map<double, vector<int> > geneRankMap;