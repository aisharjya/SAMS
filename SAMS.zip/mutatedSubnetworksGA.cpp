/*
 * mutatedSubnetworksGA.cpp
 *
 *  Created on: Nov 20, 2016
 *      Author: aisharjya
 */
 
#include <iostream>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include "common.h"
#include "ProcessInput.h"

using namespace std;

int randNoGen(int min, int max) {
	//srand(time(0));
	float r = (float)rand() / (float)RAND_MAX;
	return (int)round(min + r * (max - min));
}

float logrank_statistic(vector<vector<int> > _P0, vector<vector<int> > _P1) {
	//cout << "Within logrank_static: " << _P0.size() << " " << _P1.size() << endl;
	float pValue=0;
	const int mP0=_P0.size();
	const int mP1=_P1.size();
	const int mTotal=(mP0+mP1);
	float qPart1=(mP0*mP1)/(float)(mTotal*(mTotal-1));
	float qPart2=0.0;
	float qPart3=0.0;
	float partV0=0.0;
	float partV1=0.0;
	int xP0=0;
	int xP1=1;
	float q=0;
	float V=0.0;
	//cout << "mP0: " << mP0 << " mP1: " << mP1 << " mTotal: " << mTotal << " qPart1: " << qPart1 << endl;
	for (int pp=0; pp<mTotal; pp++){
		if (pp<mP0){
			if (_P0[pp][2]==1){
				//V=V+(xP0-((mP1-partV0)/(float)(mTotal-(_P0[pp][0]+1)+1)));
				V=V+(xP0-((float)(mP1-partV0)/(float)(mTotal-(_P0[pp][0])+1)));
				qPart2=qPart2+1;
				//qPart3=qPart3+(1/(float)(mTotal-(_P0[pp][0]+1)+1));
				qPart3=qPart3+((float)1.0/(float)(mTotal-(_P0[pp][0])+1));
			}
		} else {
			if (_P1[(pp-mP0)][2]==1){				
				partV1=0;
				for(int subInx=0; subInx<(((pp-mP0)+1)-1); subInx++){	
					partV1=partV1+1;
				}
				//V=V+(xP1-((mP1-partV1)/(float)(mTotal-(_P1[(pp-mP0)][0]+1)+1)));
				V=V+(xP1-((float)(mP1-partV1)/(float)(mTotal-(_P1[(pp-mP0)][0])+1)));
				//cout << "V: " << V << endl;
				qPart2=qPart2+1;
				//qPart3=qPart3+(1/(float)(mTotal-(_P1[(pp-mP0)][0]+1)+1));
				qPart3=qPart3+((float)1.0/(float)(mTotal-(_P1[(pp-mP0)][0])+1));
			}
		}
	}	
	q=sqrt(qPart1*(qPart2-qPart3));
	//cout << V << " " << q << " " << qPart1 << " " << qPart2 << " " << qPart3 << endl;
	pValue=(float)V/q;
	//cout << "pValue: " << pValue << endl;
	return pValue;
}

bool checkNodeExistence(vector<int> solution, int queryNode, int size){
	//cout << "checkNodeExistence: " << queryNode << " " << size << endl;
	for(int i=0; i<size; i++){
		if(queryNode==solution[i])
		   return true;
	}
	return false;
}

int addDirectNeighbors(int nodeNo, int len, vector<int> &solution, int solutionLen){
	//cout << "Within addDirectNeighbors: " << nodeNo << " " << len << endl;
	vector<int> _v=adjNodeList.find(nodeNo)->second;
	bool flag=true;
	for(int i=0; i<_v.size(); i++){
		flag=checkNodeExistence(solution, _v[i], len);
		if(flag==false){
		   flag=true;
		   if(len<solutionLen){
			  solution[len]=_v[i];
			  len++;
		   }else
			  break;
	    }
	}
	//cout << "len: " << len << endl;
	 return len;
}

int addIndirectNeighbors(int nodeNo, int len, vector<int> &solution, int solutionLen){
	//cout << "Within addIndirectNeighbors: " << nodeNo << endl;
	int r;
	r=randNoGen(0, len-1);
	//vector<int> _u=adjNodeList.find(nodeNo)->second;
	//cout << "solution[r]: " << solution[r] << endl;
	vector<int> _u=adjNodeList.find(solution[r])->second;
	bool flag=true;
	int _loopCounter=0;
	while(flag==true){
		  _loopCounter++;
		  r=randNoGen(0, _u.size()-1);
		  //check node existence
		  flag=checkNodeExistence(solution, _u[r], len);
		  if(_loopCounter==10)
			 break;
	}
	if(flag==false && len<solutionLen){
	   solution[len]=_u[r];
	   len++;
	}
	flag=true;
	if(len<solutionLen){
	   vector<int> _v=adjNodeList.find(_u[r])->second;
	   //check node existence
	   for(int i=0; i<_v.size(); i++){
		   flag=checkNodeExistence(solution, _v[i], len);
		   if(flag==false){
			   flag=true;
			   if(len<solutionLen){
				  solution[len]=_v[i];
				  len++;
			   }else
					break;
		   }
	   }
	}
	return len;
}

void mergePopulation(){
	for(int p=0; p<parentPopulation.size(); p++)
		mergedPopulation.push_back(parentPopulation[p]);
	
	for(int p=0; p<childPopulation.size(); p++)
		mergedPopulation.push_back(childPopulation[p]);
	
	//cout << "mergedPopulation.size(): " << mergedPopulation.size() << endl;
}

void selection(){
	//cout << "Within selection()." << endl;
	scoreMap.clear();
	map<double, int>().swap(scoreMap);
	for(int t=0; t<mergedPopulation.size(); t++){
		_P0.clear();
		vector<vector<int> >().swap(_P0);
		_P1.clear();
		vector<vector<int> >().swap(_P1);
		float pVal=0.00;
		for(int s=0; s<mutationData.size(); s++){
			bool mutationFlag=false;
			for(int p=0; p<mergedPopulation[0].size(); p++){
				//cout << "t: " << t << " s: " << s << " p: " << p << " mergedPopulation[t][p]+1: " << mergedPopulation[t][p]+1 << endl;
				//if(mutationData[s][p+1]==1){
				if(mutationData[s][mergedPopulation[t][p]+1]==1){
					_P1.push_back(patientData[s]);
					mutationFlag=true;
					break;
				}
			}
			if(mutationFlag==false)
				_P0.push_back(patientData[s]);
		}
		pVal=logrank_statistic(_P0, _P1);
		//cout << " pVal: " << pVal << endl;
	    while(scoreMap.count(pVal)==1){
		      pVal+=0.000001;
	    }
		//cout << " pVal: " << pVal << " t: " << t << " _P0.size(): " << _P0.size() << " _P1.size(): " << _P1.size() << endl;
		scoreMap.insert( pair<double,int>(pVal, t) );
	}
	/*cout << "Score Map: " << endl;
	std::map<double,int>::reverse_iterator rit;
	for(rit=scoreMap.rbegin(); rit!=scoreMap.rend(); ++rit)
		cout << "mergedData index: " << rit->first << "->" << rit->second << endl;*/
	
	parentPopulation.clear();
	int _count=0;
	std::map<double,int>::reverse_iterator _rit;
	_bestSol.resize(solutionLen);
	map<int, int> bestSolMap;
	for(_rit=scoreMap.rbegin(); _rit!=scoreMap.rend(); ++_rit){
		if(_count==0){
			//cout << "Best Sol.: " << _rit->first << " : ";
			for(int t=0; t<mergedPopulation[_rit->second].size(); t++){
				_bestSol[t]=mergedPopulation[_rit->second][t];
				logRankScore=_rit->first;
			    //cout << _bestSol[t] << " ";
			}
			//cout << endl;
		}
		if(_count>9)
		   break;
		parentPopulation.push_back(mergedPopulation[_rit->second]);
		bestSolMap.insert ( pair<int,int>(_rit->second, 1) );
		_count++;
	}
	//cout << "_count: " << _count << " parentPopulation.size(): " << parentPopulation.size() << endl;
	for(int k=0; k<(parentPopSize-_count); k++){
		int r=randNoGen(0, 199);
		while( bestSolMap.count(r)!=0 ){
			r=randNoGen(0, 199);
		}
		parentPopulation.push_back(mergedPopulation[r]);
	}
	//cout << "parentPopulation.size(): " << parentPopulation.size() << endl;
	cout << "Exit from selection()." << endl;
}

void mutation(){
	for(int i=0; i<childPopulation.size(); i++){
		int r1=randNoGen(0, solutionLen-1); //position to be replaced
		int r2=randNoGen(0, solutionLen-1); //position with whose neighbor to be replaced with
		if(r1==r2){
		   i=i-1;
		   continue;
		}
		int node2=childPopulation[i][r2];
		vector<int> neighbors=adjNodeList.find(node2)->second;
		int r3=randNoGen(0, neighbors.size()-1); //node to be replaced with
		int node3=neighbors[r3];
		bool _ind=false;
		for(int t=0; t<childPopulation[i].size(); t++){
			int _loop=0;
			_ind=false;
			while(childPopulation[i][t]==node3){
				  if(_loop>5){
					 _ind=true;
				     break;
				  }
				  r3=randNoGen(0, neighbors.size()-1); //node to be replaced with
				  node3=neighbors[r3];
				  _loop++;
			}
			if(_ind==true)
			   break;
		}
		if(_ind==true){
		   i=i-1;
		   continue;
		} else
			childPopulation[i][r1]=node3;
	}
	/*cout << "After mutation...childPopulation: " << endl;
	for(int t=0; t<childPopulation.size(); t++){
		for(int p=0; p<childPopulation[0].size(); p++)
			cout << childPopulation[t][p] << " ";
		cout << endl;
	}*/
}

/*void crossOver() {
	cout << "Within crossOver()" << endl;
	int _loopCounter=0;
	for(int i=0; i<parentPopulation.size(); i++){
		int r=randNoGen(0, parentPopSize-1);
		while(i==r)
			r=randNoGen(0, parentPopSize-1);
		cout << "i: " << i << " r: " << r << endl;
		
		for(int k=0; k<solutionLen; k++)
			cout << parentPopulation[i][k] << " ";
		cout << endl;
		
		for(int k=0; k<solutionLen; k++)
			cout << parentPopulation[r][k] << " ";
		cout << endl;
	}
	cout << "Exit from crossover" << endl;
}*/

void crossOver() {
	cout << "Within crossOver() - solutionLen: " << solutionLen << " parentPopulation.size(): " << parentPopulation.size() << " adjNodeList.size(): " << adjNodeList.size() << endl;
	//cout << "Within crossOver: childPopulation[0][0] " << childPopulation[0][0] << " mergedPopulation.size(): " << mergedPopulation.size() << endl;
	int _loopCounter=0;
	for(int i=0; i<parentPopulation.size(); i++){
		int r=randNoGen(0, parentPopSize-1);
		vector<int> _rSol;
		_rSol.clear();
		_rSol.resize(solutionLen);
		vector<int> _common;
		_common.clear();
		_common.resize(solutionLen, -1);
		vector<int> _remaining;
		_remaining.clear();
		_remaining.resize(2*solutionLen, -1);
		vector<float> _logRankScore;
		_logRankScore.clear();
		_logRankScore.resize(2*solutionLen, -99.0);
		vector<int> _sortIndex;
		_sortIndex.clear();
		_sortIndex.resize(2*solutionLen, -1);
		vector<int> _toRemove;
		_toRemove.clear();
		_toRemove.resize(solutionLen, -1);
		while(i==r){
			  r=randNoGen(0, parentPopSize-1);
		}
		//cout << "r: " << r << " i: " << i << " ";
		_rSol=parentPopulation[r];
		/*cout << "Random Solution: ";
		for(int x=0; x<_rSol.size(); x++)
			cout << _rSol[x] << " ";
		cout << endl;
		cout << "Parent Solution: ";
		for(int x=0; x<parentPopulation[i].size(); x++)
			cout << parentPopulation[i][x] << " ";
		cout << endl;*/
		
		/* Comparing current solution with randomly selected solution. Preparing the _common and _remaining vectors */
		for(int p=0; p<parentPopulation[i].size(); p++){
			bool marker=false;
			for(int q=0; q<_rSol.size(); q++){
				//cout << "_rSol[q]: " << _rSol[q] << " parentPopulation[i][p]: " << parentPopulation[i][p] << endl;
				if(parentPopulation[i][p]==_rSol[q]){
				   marker=true;
				   for(int t=0; t<_common.size(); t++){
					   if(_common[t]==-1 || _common[t]>(totalNodes-1)){
						  _common[t]=parentPopulation[i][p];
					      break;
					   }
				   }				   
				   break;
				}
			}
			if(marker==false){
				for(int t=0; t<_remaining.size(); t++){
					if(_remaining[t]==-1 || _remaining[t]>(totalNodes-1)){
					   _remaining[t]=parentPopulation[i][p];
					   break;
					}
				}
			}
		}
		
		/* When no nodes are common between a solution and the randomly selected solution */
		if(_common[0]==-1 || _common[0]>(totalNodes-1)){
		   if(_loopCounter>50){
			   _loopCounter=0;
			   for(int m=0; m<parentPopulation[i].size(); m++)
				   childPopulation[i][m]=parentPopulation[i][m];
			   continue;
		   }else{
			   i=i-1;
			   _loopCounter++;
			   continue;
		   }
		}

		_loopCounter=0;
		for(int t=0; t<_rSol.size(); t++){
			bool flag1=false;
			for(int p=0; p<_common.size(); p++){
				if(_common[p]!=-1 && _common[p]==_rSol[t]){
				   flag1=true;
				   break;
				}
			}
			if(flag1==false){
			   for(int k=0; k<_remaining.size(); k++){
				   if(_remaining[k]==-1 || _remaining[k]>(totalNodes-1)){
					  _remaining[k]=_rSol[t];
					  break;
				   }
			   }
			}
		}
		//cout << "for(int t=0; t<_rSol.size(); t++).." << endl;
		int t;
		for(t=0; t<_common.size(); t++){
			if(_common[t]==-1 || _common[t]>(totalNodes-1))
			   break;
		}
		//cout << "for(t=0; t<_common.size(); t++).." << endl;
		if(t>=solutionLen || _common[0]==-1 || _common[0]>(totalNodes-1)){ //duplicate solution
			//cout << "Within if.." << endl;
			i=i-1;
		} else {
			//cout << "Within else.." << endl;
		   //check adjacency	
		   for(int x=0; x<_common.size(); x++){
			   if(_common[x]==-1 || _common[1]==-1 
								 || _common[x]>(totalNodes-1) 
								 || _common[1]>(totalNodes-1)) //if _common[1]==-1 -> only one common node; no need to remove.
				  break;
			   bool ind=false;
			   int aNode=_common[x];
			   vector<int> neighbors=adjNodeList.find(aNode)->second;
			   for(int y=0; y<_common.size(); y++){
				   if(x==y)
					  continue;
				   for(int z=0; z<neighbors.size(); z++){
					   if(neighbors[z]==_common[y] && _common[y]!=-1){
						  ind=true;
						  break;
					   }else
						   ind=false;
				   }
				   if(ind==true)
					  break;
			   }
			   if(ind==false){
				  for(int t=0; t<_toRemove.size(); t++){
					  if(_toRemove[t]==-1 || _toRemove[t]>(totalNodes-1))
						 _toRemove[t]=aNode;
					  break;
				  }
			   }
		   }
		   //cout << "for(int k=0; k<_toRemove.size(); k++).." << endl;
		   for(int k=0; k<_toRemove.size(); k++){
			   if(_toRemove[k]==-1 || _toRemove[k]>(totalNodes-1))
				  break;
			   int int_to_remove=_toRemove[k];
			   //_common.erase(std::remove(_common.begin(), _common.end(), int_to_remove), _common.end());
			   auto it=std::find(_common.begin(), _common.end(), int_to_remove);
			   if (it!=_common.end()) {
			       using std::swap;
			       // swap the one to be removed with the last element
				   // and remove the item at the end of the container
				   // to prevent moving all items after 'int_to_remove' by one
			       swap(*it, _common.back());
			       _common.pop_back();
				   //_common[_common.size()-1]=-1;
			   }
		   }
		   /*cout << "Common Nodes: ";
		   for(int t=0; t<_common.size(); t++)
			   cout << _common[t] << " ";
		   cout << endl;
		   cout << "Remaining nodes: ";
		   for(int t=0; t<_remaining.size(); t++)
			   cout << _remaining[t] << " ";
		   cout << endl;*/
		   for(int t=0; t<_common.size(); t++){	// check node adjacency in _common list.
			   if(_common[t]==-1 || _common[t]>(totalNodes-1))
				  break;
				  //continue;
			   else {
				  if(t==0) 
					childPopulation[i][t]=_common[t];
				  else {	
					  int aNode=_common[t];
					  vector<int> _neighborList=adjNodeList.find(aNode)->second;
					  for(int x=0; x<_neighborList.size(); x++){
						  bool _present=false;
						  for(int y=0; y<childPopulation[i].size(); y++){
							  if(childPopulation[i][y]==-1)
								 break; 
							  if(childPopulation[i][y]==_neighborList[x]){
								 for(int s=0; s<childPopulation[i].size(); s++){
									 if(childPopulation[i][s]==-1){
										childPopulation[i][s]=_common[t];
										_present=true;
										break;
									 }
								 }
							  }
							  if(_present==true)
								 break;
						  }
						  if(_present==true)
							 break;
					  }
				  }
			   }
		   }
		   //cout << "for(int t=0; t<_remaining.size(); t++).." << endl;
		   scoreMap.clear();
		   map<double, int>().swap(scoreMap);
		   for(int t=0; t<_remaining.size(); t++){	//scoring the remaining nodes according to logRankStatistic
			   if(_remaining[t]==-1 || _remaining[t]>(totalNodes-1))
				  break;
			   else {
				   //cout << "_remaining[t]: " << _remaining[t] << " ";
				   _P0.clear();
				   vector<vector<int> >().swap(_P0);
				   _P1.clear();
				   vector<vector<int> >().swap(_P1);
				   for(int z=0; z<mutationData.size(); z++){
					   if(mutationData[z][_remaining[t]+1]==0){
						  _P0.push_back(patientData[z]); 
					   }
					   if(mutationData[z][_remaining[t]+1]==1){
						  _P1.push_back(patientData[z]); 
					   }
				   }
				   //cout << "_P0 & _P1: " << _P0.size() << " " << _P1.size() << endl;
				   float pVal=logrank_statistic(_P0, _P1);
				   //cout << " pVal: " << pVal << endl;
				   while(scoreMap.count(pVal)==1){
					   pVal+=0.00001;
				   }
				   scoreMap.insert ( pair<double,int>(pVal, _remaining[t]) );
			   }
		   }
		    //cout << "Score Map: " << endl;
			//cout << "for(rit=scoreMap.rbegin(); rit!=scoreMap.rend(); ++rit).." << endl;
			std::map<double,int>::reverse_iterator rit;
		   	for(rit=scoreMap.rbegin(); rit!=scoreMap.rend(); ++rit){
				//cout << "Node: " << rit->second << "->" << rit->first << endl;
				/*if(childPopulation[i][solutionLen-1]!=-1)
					break;*/
				vector<int> _neighborList=adjNodeList.find(rit->second)->second;
				for(int u=0; u<_neighborList.size(); u++){
					bool _yes=false;
					for(int v=0; v<childPopulation[i].size(); v++){
						if(childPopulation[i][v]==_neighborList[u] && childPopulation[i][v]!=-1
									&& childPopulation[i][v]<(totalNodes-1)){ // check node adjacency in _common list.
							for(int t=(v+1); t<childPopulation[i].size(); t++){
								if(childPopulation[i][t]==-1 || childPopulation[i][t]>(totalNodes-1)){
									_yes=true;
									childPopulation[i][t]=rit->second;
									break;
								}
							}
						}
						if(_yes==true)
						   break;
					}
					if(_yes==true)
					   break;
				}
			}
			/*cout << "for(int d=0; d<childPopulation[i].size(); d++).." << endl;
			for(int x=0; x<childPopulation[i].size(); x++)
				cout << childPopulation[i][x] << " ";
			cout << endl;*/
			/*for(int d=0; d<childPopulation[i].size(); d++){
				//if(childPopulation[i][solutionLen-1]==-1){
				if(childPopulation[i][d]==-1 || childPopulation[i][d]>(totalNodes-1)){	
					//for(int t=childPopulation[i].size()-1; t>0; t--){
					for(int t=0; t<childPopulation[i].size(); t++){
						//while(childPopulation[i][t]==-1 || childPopulation[i][t]>(totalNodes-1)){
						if(childPopulation[i][t]==-1 || childPopulation[i][t]>(totalNodes-1)){
							bool _ind=false;
							for(int x=0; x<childPopulation[i].size(); x++){
								vector<int> _neighs=adjNodeList.find(childPopulation[i][x])->second;
								for(int y=0; y<_neighs.size(); y++){
									for(int w=0; w<childPopulation[i].size(); w++){
										if(childPopulation[i][w]==_neighs[y]){
											_ind=true;
											break;
										}
									}
									if(_ind==false){
										childPopulation[i][t]=_neighs[y];
										break;
									}
								}
								if(_ind==false)
									break;
							}
							if(_ind==false)
								break;
							//t--;	//doubt
						}
					}
				}
			}*/
			//cout << "End: for(int d=0; d<childPopulation[i].size(); d++).." << endl;
			for(int d=0; d<childPopulation[i].size(); d++){
				if(childPopulation[i][d]==-1 || childPopulation[i][d]>(totalNodes-1)){
					i=i-1;
					break;
				}
			}
	    }
		/*cout << "child pop: ";
		for(int t=0; t<childPopulation[0].size(); t++)
			cout << childPopulation[i][t] << " ";
		cout << endl;*/
	}
	/*cout << "crossOver()..childPopulation: " << endl;
	for(int t=0; t<childPopulation.size(); t++){
		for(int p=0; p<childPopulation[0].size(); p++)
			cout << childPopulation[t][p] << " ";
		cout << endl;
	}*/
	cout << "Exit from crossover" << endl;
}

void getScore(){
	scoreMap.clear();
	map<double, int>().swap(scoreMap);
	for(int t=0; t<initPopSize; t++){
		_P0.clear();
		vector<vector<int> >().swap(_P0);
		_P1.clear();
		vector<vector<int> >().swap(_P1);
		float pVal=0.00;
		for(int s=0; s<mutationData.size(); s++){
			bool mutationFlag=false;
			for(int p=0; p<initSolLen; p++){
				if(mutationData[s][parentPopulation[t][p]+1]==1){
					_P1.push_back(patientData[s]);
					mutationFlag=true;
					break;
				}
			}
			if(mutationFlag==false)
				_P0.push_back(patientData[s]);
		}
		cout << "_P0.size() with getScore(): " << endl;
		cout << _P0.size() << endl;
		pVal=logrank_statistic(_P0, _P1);
		while(scoreMap.count(pVal)==1){
			  pVal+=0.000001;
		}
		scoreMap.insert( pair<double,int>(pVal, t) );
	}
}

void createSolutions(int index){
	geneRankMap.clear();
	map<double, vector<int> >().swap(geneRankMap);
	
	vector<int> solution;
	solution.resize(initSolLen);
	
	map<int, int> solutionGenes;
	solutionGenes.clear();
	map<int, int>().swap(solutionGenes);
	
	vector<double> _fi;
	_fi.clear();
	
	for(int i=0; i<initSolLen; i++)	//initSolLen=100
		solution[i]=-1;
	int nodeNo=randNoGen(0, totalNodes-1);
	while(adjNodeList.find(nodeNo)==adjNodeList.end()){
		nodeNo=randNoGen(0, totalNodes-1);
	}
	solution[0]=nodeNo;
	solutionGenes.insert( pair<int, int>(solution[0], solution[0]) );
	
	for(int i=1; i<initSolLen; i++) {
		vector<int> _v=adjNodeList.find(nodeNo)->second;
		/*cout << "_v vector contents: " << endl;
		for(int i=0; i<_v.size(); i++){
			cout << _v[i] << " ";
		}
		cout << endl;*/
		for(int k=0; k<_v.size(); k++){
			
			if(solutionGenes.count(_v[k])>0)
				continue;
			
			if(geneRankMap.count(geneSurvivalTimeMap.find(_v[k])->second)>0){
				vector<int> _vList;
				_vList=geneRankMap.find(geneSurvivalTimeMap.find(_v[k])->second)->second;
				_vList.push_back(_v[k]);
				geneRankMap.insert( pair<double, vector<int> >(geneSurvivalTimeMap.find(_v[k])->second, _vList) );
			}else{
				vector<int> _vList;
				_vList.push_back(_v[k]);
				geneRankMap.insert( pair<double, vector<int> >(geneSurvivalTimeMap.find(_v[k])->second, _vList) );
			}
			//cout << "_fi.size(): " << _fi.size() << endl;
		}
		
		/*cout << "geneRankMap contents: " << endl;
		for(map<double, vector<int> >::iterator it=geneRankMap.begin(); it!=geneRankMap.end(); ++it)
			cout << it->first << " => " << it->second.size() << '\n';*/
		
		vector<int> _vSols=geneRankMap.begin()->second;
		//cout << "Lowest Average Survival Time: " << geneRankMap.begin()->first << endl;
		//cout << "Before. _vSols vector contents: " << endl;
		/*for(int i=0; i<_vSols.size(); i++){
			cout << _vSols[i] << " ";
		}
		cout << endl;*/
		
		int _nodeIdx=randNoGen(0, _vSols.size()-1);		
		//cout << "Node Index: " << _nodeIdx << endl;
		
		solution[i]=_vSols[_nodeIdx];
		solutionGenes.insert( pair<int, int>(solution[i], solution[i]) );	
		//cout << "_vSols[_nodeIdx]: " << _vSols[_nodeIdx] << endl;
		
		_vSols.erase(_vSols.begin()+_nodeIdx);
		
		/*cout << "After. _vSols vector contents: " << endl;
		for(int i=0; i<_vSols.size(); i++){
			cout << _vSols[i] << " ";
		}
		cout << endl;*/
		
		if(_vSols.size()>0)
			geneRankMap.insert( pair<double, vector<int> >(geneRankMap.begin()->first, _vSols) );
		else
			geneRankMap.erase(geneRankMap.begin()->first);
		
		nodeNo=solution[i];
	}
	for(int j=0; j<parentPopulation[0].size(); j++)
		parentPopulation.at(index).at(j)=solution[j];
}

/*int createLongerSols(){
	for(int u=0; u<initPopSize; u++){	//initPopSize=1000
		createSolutions(u);
	}
	cout << "Print initial population: " << endl;
	for(int x=0; x<initPopSize; x++){
		for(int y=0; y<initSolLen; y++){
			cout << parentPopulation[x][y] << " ";
		}
		cout << endl;
	}	
	//test
	getScore();
	cout << "scoreMap.size(): " << scoreMap.size() << endl;
	adjNodeList.clear();
	map<int, vector<int> >().swap(adjNodeList);
	map<double,int>::reverse_iterator rit;
	int counter=0;
	for(rit=scoreMap.rbegin(); rit!=scoreMap.rend(); ++rit){
		counter++;
		cout << "Score: " << rit->first << endl;
		int rowIndex=rit->second;
		for(int p=0; p<initSolLen; p++){
			if(adjNodeList.find(parentPopulation[rowIndex][p])==adjNodeList.end()){
				adjNodeList.insert( pair<int, vector<int> >(parentPopulation[rowIndex][p], vector<int>()) );
			}
		}
		if(counter>=500)
			break;
	}
	cout << "adjNodeList.size(): " << adjNodeList.size() << endl;
	//test end
	// Create the adjNodeList based on initSolution
	map<int,vector<int> >::iterator _it;
	for(_it=adjNodeList.begin(); _it!=adjNodeList.end(); ++_it){
		vector<int> adjNodes;
		map<int,vector<int> >::iterator _it_inner;
		for(_it_inner=adjNodeList.begin(); _it_inner!=adjNodeList.end(); ++_it_inner){
			if(_it->first!=_it_inner->first){
				if(adjGraph[_it->first][_it_inner->first]==1)
					adjNodes.push_back(_it_inner->first);
			}else
				continue;
		}
		if(!adjNodes.empty()){
			adjNodeList[ _it->first ]=adjNodes;
		}
	}	
	parentPopulation.clear();
	vector<vector<int> >().swap(parentPopulation);
}*/

int createLongerSols(){
	cout << "Within createLongerSols()." << endl;
	for(int u=0; u<initPopSize; u++){
		vector<int> solution;
		solution.resize(initSolLen);
		for(int i=0; i<initSolLen; i++)
			solution[i]=-1;
		int nodeNo=randNoGen(0, totalNodes-1);
		while(adjNodeList.find(nodeNo)==adjNodeList.end()){
			nodeNo=randNoGen(0, totalNodes-1);
		}
		cout << "nodeNo: " << nodeNo << endl;
		solution[0]=nodeNo;
		int len=1;
		int _counter=0;
		bool _marker=false;
		bool flag=false;
		while(len<initSolLen){
			_counter++;
			int choose;
			if(flag==true)
			   choose=2;
			else
				choose=randNoGen(1, 2);
			switch(choose) {
				case 1 : len=addDirectNeighbors(nodeNo, len, solution, initSolLen);
						 flag=true;
						 break;
						 
				case 2 : len=addIndirectNeighbors(nodeNo, len, solution, initSolLen);
						 break;
			}
			if(len<initSolLen)
			   continue;
		   
			if(_counter>initSolLen){
				_marker=true;
				break;
			}
		}
		if(_marker==true){
			cout << "within if(_marker==true)." << endl;
			u=u-1;
			continue;
		}
		for(int j=0; j<parentPopulation[0].size(); j++)
			parentPopulation.at(u).at(j)=solution[j];
	}
	
	for(int x=0; x<initPopSize; x++){
		for(int y=0; y<initSolLen; y++){
			cout << parentPopulation[x][y] << " ";
		}
		cout << endl;
	}
	
	cout << "Before getScore(). " << endl;
	getScore();								//populate P0 and P1
	cout << "scoreMap.size(): " << scoreMap.size() << endl;
	adjNodeList.clear();
	map<int, vector<int> >().swap(adjNodeList);
	map<double,int>::reverse_iterator rit;
	int counter=0;
	for(rit=scoreMap.rbegin(); rit!=scoreMap.rend(); ++rit){
		counter++;
		cout << "Score: " << rit->first << endl;
		int rowIndex=rit->second;
		for(int p=0; p<initSolLen; p++){
			if(adjNodeList.find(parentPopulation[rowIndex][p])==adjNodeList.end()){
				adjNodeList.insert( pair<int, vector<int> >(parentPopulation[rowIndex][p], vector<int>()) );
			}
		}
		if(counter>=500)
			break;
	}
	cout << "adjNodeList.size(): " << adjNodeList.size() << endl;
	//test end

	map<int,vector<int> >::iterator _it;
	for(_it=adjNodeList.begin(); _it!=adjNodeList.end(); ++_it){
		vector<int> adjNodes;
		map<int,vector<int> >::iterator _it_inner;
		for(_it_inner=adjNodeList.begin(); _it_inner!=adjNodeList.end(); ++_it_inner){
			if(_it->first!=_it_inner->first){
				if(adjGraph[_it->first][_it_inner->first]==1)
					adjNodes.push_back(_it_inner->first);
			}else
				continue;
		}
		if(!adjNodes.empty()){
			adjNodeList[ _it->first ]=adjNodes;
		}
	}	
	parentPopulation.clear();
	vector<vector<int> >().swap(parentPopulation);
}

int main(int argc, char *argv[]) {
	/**** Start: Step 1 of GA ****/
	freopen("outTwoStepGA", "w", stdout);
	srand(time(NULL));
	totalNodes=atoi(argv[1]);
	cout << "totalNodes: " << totalNodes << " " << argv[2] << endl;
	ProcessInput pi;
	pi.loadNetworkData(argv[2]);
	pi.loadMutationData(argv[3]);
	pi.loadPatientData(argv[4]);
	pi.genAdjList();
	pi.printAdjList();
	//pi.calcAvgSurvivalTime();
	visited.clear();
	visited.resize(totalNodes, false);
	for(int i=0; i<totalNodes; i++){
		if(!visited[i]){
			pi.depthFirstSearch(i);
		}
	}	
	pi.initParentPopulation(initSolLen, initPopSize);
	cout << "After initParentPopulation ~ Step 1" << endl;
	createLongerSols();
	pi.printAdjList();
	//fclose (stdout);
	/**** Start: Step 2 of GA ****/
cout << "Strat: Step 2 of GA" << endl;	
pi.flushMemory();	
for(solutionLen=4; solutionLen<=10; solutionLen++){
	cout << "Solution Length: " << solutionLen << endl;
	pi.initParentPopulation(solutionLen, parentPopSize);
	pi.initChildPopulation(solutionLen);
	int repNo=0;
	int start_s = clock();
	int _iter;
	for(_iter=0; _iter<maxIterationNo; _iter++){
		cout << "Iteration No.: " << _iter << endl;
		if(_iter==0){
			for(int u=0; u<parentPopSize; u++){
				vector<int> solution;
				solution.resize(solutionLen);
				for(int i=0; i<solutionLen; i++)
					solution[i]=-1;
				int nodeNo=randNoGen(0, totalNodes-1);
				while(adjNodeList.find(nodeNo)==adjNodeList.end()){
					nodeNo=randNoGen(0, totalNodes-1);
				}
				solution[0]=nodeNo;
				int len=1;
				int _counter=0;
				bool _marker=false;
				bool flag=false;
				while(len<solutionLen){
					_counter++;
					int choose;
					if(flag==true)
					   choose=2;
					else
						choose=randNoGen(1, 2);
					switch(choose) {
						case 1 : len=addDirectNeighbors(nodeNo, len, solution, solutionLen);
								 flag=true;
								 break;
								 
						case 2 : len=addIndirectNeighbors(nodeNo, len, solution, solutionLen);
								 break;
					}
					if(len<solutionLen){
						cout << "len: " << len << " solutionLen: " << solutionLen << " nodeNo: " << nodeNo << endl;
						continue;
					}
				   
					if(_counter>solutionLen){
						_marker=true;
						break;
					}
				}
				if(_marker==true){
					u=u-1;
					continue;
				}
				for(int j=0; j<parentPopulation[0].size(); j++)
					parentPopulation.at(u).at(j)=solution[j];
			}
		}
		pi.printPopulation();
		cout << "Before crossOver - solutionLen: " << solutionLen << endl;
		crossOver();
		cout << "After crossOver - solutionLen: " << solutionLen << endl;
		mutation();
		cout << "After mutation - solutionLen: " << solutionLen << endl;
		mergePopulation();
		//pi.printMergedPopulation();
		cout << "After mergePopulation - solutionLen: " << solutionLen << endl;
		selection();
		cout << "After Selection - solutionLen: " << solutionLen << endl;
		bool _flg=false;
		if(_iter!=0){
			for(int t=0; t<_prevBestSol.size(); t++){
				_flg=false;
				for(int s=0; s<_bestSol.size(); s++){
					if(_prevBestSol[t]==_bestSol[s]){
						_flg=true;
						break;
					}
				}
				if(_flg==false)
				   break;
			}
		}
		if(_flg==false){
			repNo=0;
			//_prevBestSol.clear();
			_prevBestSol.resize(solutionLen);
			for(int t=0; t<_bestSol.size(); t++)
				_prevBestSol[t]=_bestSol[t];
		}else
			repNo++;
		childPopulation.clear();
		pi.initChildPopulation(solutionLen);
		mergedPopulation.clear();
		if(repNo>maxRepeatationNo)
		   break;
	}
	int stop_s = clock();
	cout << "Total time: " << (stop_s - start_s) / double(CLOCKS_PER_SEC) << endl;
	cout << "Average time: " << ((stop_s - start_s) / double(CLOCKS_PER_SEC))/_iter << endl;
	cout << "Best Solution: ";
	for(int t=0; t<_bestSol.size(); t++){
		cout << _bestSol[t] << " ";
	}
	cout << endl;
	cout << "LogRankScore: " << logRankScore << endl;
	pi.flushMemory();
}
fclose (stdout);
adjNodeList.clear();
map<int, vector<int> >().swap(adjNodeList);
mutationData.clear();
vector<vector<int> >().swap(mutationData);
patientData.clear();
vector<vector<int> >().swap(patientData);
//}
}